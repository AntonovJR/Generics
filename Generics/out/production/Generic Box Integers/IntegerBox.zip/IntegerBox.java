import java.util.ArrayList;
import java.util.List;

public class IntegerBox<T> {
    private List<T> values;

    public IntegerBox() {
        this.values = new ArrayList<>();
    }

    public void add(T element) {
        this.values.add(element);

    }

    public void print() {
        StringBuilder sb = new StringBuilder();
        for (T value : values) {
            System.out.println(value.getClass().getName()+": "+value);

        }
    }

}
