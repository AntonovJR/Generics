import java.util.ArrayList;
import java.util.List;

public class BoxCompare<T> {
    private List<T> values;

    public BoxCompare() {
        this.values = new ArrayList<>();
    }
    public void add(T element) {
        this.values.add(element);

    }



    public <T extends Comparable<T>> void print(T bigger) {
        int n = 0;
        if (values.size() == 0) throw new IllegalArgumentException();
        for (int i = 1; i < values.size(); i++) {
            if (bigger.compareTo((T) values.get(i)) < 0){
                n++;
            }

        }
        System.out.println(n);
    }
}
