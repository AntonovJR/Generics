import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SmartArray<String> smartArray = new SmartArray();
        String input = scanner.nextLine();
        while (!"END".equals(input)) {
            String[] tokens = input.split("\\s+");
            switch (tokens[0]) {
                case "Add":
                    smartArray.add(tokens[1]);
                    break;
                case "Remove":
                    smartArray.remove(Integer.parseInt(tokens[1]));
                    break;
                case "Contains":
                    System.out.println(smartArray.contains(tokens[1]));
                    break;
                case "Swap":
                    smartArray.swap(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
                    break;
                case "Greater":
                    smartArray.greater(tokens[1]);
                    break;
                case "Max":
                    System.out.println(String.valueOf(smartArray.getMax()));

                    break;
                case "Min":
                    System.out.println(String.valueOf(smartArray.getMin()));
                    break;
                case "Print":
                    smartArray.print();
                    break;
                case "Sort":
                    smartArray.sort();

            }

            input = scanner.nextLine();
        }
    }
}
/// Add &lt;element&gt; - Adds the given element to the end of the list
// Remove &lt;index&gt; - Removes the element at the given index
// Contains &lt;element&gt; - Prints if the list contains the given element (true or false)
// Swap &lt;index&gt; &lt;index&gt; - Swaps the elements at the given indexes
// Greater &lt;element&gt; - Counts the elements that are greater than the given element and prints their count
// Max - Prints the maximum element in the list
// Min - Prints the minimum element in the list
// Print - Prints all elements in the list, each on a separate line
// END - stops the reading of commands